import Form.ThongKeKhachHangFrm29;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        ThongKeKhachHangFrm29 frame = new ThongKeKhachHangFrm29();
        frame.setVisible(true);
    }
}